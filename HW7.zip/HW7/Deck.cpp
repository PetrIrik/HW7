#include<iostream>
#include"Deck.h"


Deck::Deck()
{
	m_aCards.reserver(52);
	Populate();
}
void Deck::Pooulate()
{
}