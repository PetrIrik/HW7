﻿

#include <iostream>
#include<ctime>
#include<locale>


#include"Date.h"
#include "Date.task2.h"

int main()
{
	setlocale(LC_ALL, "rus");
    time_t now = time(0);
    tm current_time;
	gmtime_s(&current_time, &now);

	auto today = std::make_unique<Date>(current_time.tm_mday, current_time.tm_mon + 1, current_time.tm_year + 1900);
	std::unique_ptr<Date> date;

	std::cout << "Сегодняшняя дата: " << std::endl;
	std::cout << "День: " << today.get()->GetDay() << std::endl;
	std::cout << "Месяц: " << today.get()->GetMonth() << std::endl;
	std::cout << "Год: " << today.get()->GetYear() << std::endl;
	std::cout << *today << std::endl;

	std::cout << "объект today: " << (static_cast<bool>(today) ? "NOT null\n" : "null\n");
	std::cout << "объект date: " << (static_cast<bool>(date) ? "NOT null\n" : "null\n");
	std::cout << "Переместим ресурс today -> date" << std::endl;
	date = move(today);
	std::cout << "объект today: " << (static_cast<bool>(today) ? "NOT null\n" : "null\n");
	std::cout << "объект date: " << (static_cast<bool>(date) ? "NOT null\n" : "null\n");

	std::cout << "Задаине 2" << std::endl;
	auto date1 = std::make_shared<Date>(29, 9, 2022);
	auto date2 = std::make_shared<Date>(30, 9, 2022);
	std::cout << "date1 = " << *date1 << std::endl;
	std::cout << "date2 = " << *date2 << std::endl;

	auto dates = maxDate(date1, date2);
	std::cout <<"date = " << *dates << std::endl;
	std::cout << "date1: " << *date1 << std::endl;
	std::cout << "date2: " << *date2 << std::endl << std::endl;

	std::cout << "Меняем местами date1 и date2: " << std::endl;
	SwapDate(date1, date2);
	std::cout << "date1: " << *date1 << std::endl;
	std::cout << "date2: " << *date2 << std::endl << std::endl;

	std::cout << "Проверяем что dateMax остался живым " << std::endl;
	std::cout << "dateMax: " << *dates << std::endl;

}
